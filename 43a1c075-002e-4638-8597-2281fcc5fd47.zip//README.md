
  # Professional README generator
  ## Description
  This command-line application dynamically generates a professional README.md file from a user's input using the inquirer package. Users can quickly and easily create a README file for their projects.
  ## Table Of Content
  *[Title](#title)

  *[Description](#description)

  *[Installation](#installation)

  *[Usage](#usage)

  *[License](#license)

  *[Contributors](#contributor)

  *[Tests](#test)

  *[Questions](#questions)

  ## Installation
  undefined
  ## Usage?
  In the command line type node and the name of your js file, then answer the questions to gnerate the readme file.
  ## License
  [![License: MIT](https://img.shields.io/badge/License-MIT-brightgreen.svg)](https://opensource.org/licenses/MIT)


  ## Contributors
  Users can create an issue or contact the repo's owner for more information.
  ## Tests
  N/A
  ## Questions
  Any questions about this project please send me a message on https://github.com/samueltuki or email me at [samuel_tuki@yahoo.com](mailto:samuel_tuki@yahoo.com)
  ## License
  This project is licensed under the MIT .
  
  ## demo
[Untitled video - Made with Clipchamp.zip](https://github.com/samueltuki/readMe-Generator/files/10854976/Untitled.video.-.Made.with.Clipchamp.zip)
